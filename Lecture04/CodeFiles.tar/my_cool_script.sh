# This is my better script
# Done using differennt approaches
# This script is not going to work
#This script is not good
